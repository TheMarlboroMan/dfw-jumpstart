#pragma once

namespace controller {

enum t_states {state_min=0,
//[new-controller-state-mark]
state_max
};

}
