#pragma once

namespace app
{

struct input_app
{
	enum inputs{
escape=0,
up,
down,
left,
right
	};

};

}
