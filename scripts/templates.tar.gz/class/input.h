#ifndef APP_INPUT_H
#define APP_INPUT_H

namespace app
{

struct input_app
{
	enum inputs{
escape=0,
up,
down,
left,
right
	};

};

}

#endif
