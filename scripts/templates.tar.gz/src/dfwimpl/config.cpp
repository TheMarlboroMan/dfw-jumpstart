#include "../../include/dfwimpl/config.h"

using namespace dfwimpl;

config::config(
	const std::string& _conf_path
)
	:dfw::base_config(_conf_path)
{ }
