#pragma once

namespace input
{

enum inputs{
escape=0,
up,
down,
left,
right
};

}
