#include "_h_file_location"

using namespace _namespace;
