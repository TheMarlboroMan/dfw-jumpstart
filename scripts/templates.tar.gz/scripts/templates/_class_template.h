#pragma once

_namespace

class _class {

	public:

};

_endnamespace
