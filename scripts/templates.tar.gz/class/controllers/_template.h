#pragma once

#include "states.h"

#include <lm/logger.h>

#include <dfw/controller_interface.h>

#include <ldv/screen.h>

#include <cmath>

namespace app {

class controller_template:
	public dfw::controller_interface {

	public:

						controller_template(lm::logger&);
	virtual void 				loop(dfw::input&, const dfw::loop_iteration_data&);
	virtual void 				draw(ldv::screen&, int);
	virtual void 				awake(dfw::input& /*input*/) {}
	virtual void 				slumber(dfw::input& /*input*/) {}
	virtual bool				can_leave_state() const {return true;}

	private:

	//references...
	lm::logger&					log;

	//properties
};

}
