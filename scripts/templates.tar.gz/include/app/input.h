#pragma once

namespace app
{

enum inputs{
escape=0,
up,
down,
left,
right
};

}
