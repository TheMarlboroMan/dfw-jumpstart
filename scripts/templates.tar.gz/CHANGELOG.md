# Changelog

All notable changes to this project "project-placeholder" will be documented in this file.

The format is based on [Keep a Changelog] and this project attempts to adhere to [Semantic Versioning].

Changes will be documented under Added, Changed, Deprecated, Removed, Fixed or Security headers.

## Known bugs:

## [v0.0.0]: xxxx-xx-xx
