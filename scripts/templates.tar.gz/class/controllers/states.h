#pragma once

namespace app {

enum t_states {state_min=0,
//new states go above here
state_max
};

}
