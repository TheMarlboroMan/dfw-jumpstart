#ifndef APP_STATES_H
#define APP_STATES_H

enum t_states {state_min=0,
state_max
};

#endif
